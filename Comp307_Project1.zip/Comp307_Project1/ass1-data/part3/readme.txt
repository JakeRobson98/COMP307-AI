To compile and execute the program:

1- Compile the source code using the command:
    javac *.java

2- Execute the compiled files using the command:
    java MakeImage

 
