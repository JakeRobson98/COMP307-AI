package part2;

/**
 * Created by Jake on 9/04/18.
 */
public class Main {
    public static void main(String[] args) {
        DTmaker r = new DTmaker(args[0], args[1]);

    }


}