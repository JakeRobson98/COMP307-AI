package part3;


/**
 * Created by Jake on 9/04/18.
 */
public class Main {
    public static void main(String[] args) {
       Perceptron p = new Perceptron(args[0]);

    }


}