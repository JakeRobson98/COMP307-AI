Please start the example via the main class examples.monalisa.gui.GeneticDrawingApp

The project was originally built using Netbeans. In the gui directory there are some form files from Netbeans Matisse for creating GUIs visually.